<?php
// Adaptez ces paramètres MySQL puis ouvrez install.php
return ['host'=>'localhost','db'=>'restaurant_adam','user'=>'root','pass'=>'','tax'=>18,'name'=>'Restaurant ADAM'];
